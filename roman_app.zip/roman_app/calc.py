a = input("Number A: ")
b = input("Number B: ")
operation = input("'+','-','*','/': ")
result = 0
if(operation == '+'):
    result = int(a) + int(b)
elif(operation == '-'):
    result = int(a) - int(b)
elif(operation == '*'):
    result = int(a) * int(b)
elif(operation == '/'):
    result = int(a) / int(b)
print(result)
